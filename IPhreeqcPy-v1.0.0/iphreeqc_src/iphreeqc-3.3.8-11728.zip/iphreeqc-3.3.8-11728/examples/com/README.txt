These examples require that IPhreeqcCOM-X.X.X-XXXX-(win32,x64).msi be installed.
64-bit operating systems should install both the win32 and x64 bit versions.  Both are
available at http://wwwbrr.cr.usgs.gov/projects/GWC_coupled/phreeqc/index.html.
