IPhreeqcPy Module
=================
.. autoclass:: IPhreeqcPy.IPhreeqc
    :members:



